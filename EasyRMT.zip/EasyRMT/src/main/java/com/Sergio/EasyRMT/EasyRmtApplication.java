package com.Sergio.EasyRMT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EasyRmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(EasyRmtApplication.class, args);
	}
}
